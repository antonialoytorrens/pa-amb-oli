// This software is released into the Public Domain.  See copying.txt for details.
package org.openstreetmap.osmosis.tagtransform;

public interface DataSource {

		String[] transform(String[] matches);

}
