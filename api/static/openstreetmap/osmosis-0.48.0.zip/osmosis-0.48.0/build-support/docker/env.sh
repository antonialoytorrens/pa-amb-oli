export gradleUserDir="${HOME}/.gradle"
export gnupgUserDir="${HOME}/.gnupg"
export userId=$(id -u)
export groupId=$(id -g)
export projectDir="$( cd "${scriptDir}"/../.. && pwd )"
